package practicafinalnb;


import java.util.*;

/**
 * 
 */
public class Mascota {

    /**
     * Default constructor
     */
   public Mascota(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    /**
     * 
     */
    private String nombre;

    /**
     * 
     */
    private int edad;


    /**
     * 
     */
    private Set<Cita> citas;

    /**
     * 
     */
    private Propietario propietario;

    /**
     * 
     */
    private Set<Historial> historiales;

    /**
     * @param fecha 
     * @return
     */
    public Historial recuperarDiagnostico(Date fecha) {
        // TODO implement here
        return (Historial) historiales;
    }

    /**
     * @param cita
     */
    public void CrearCita(Cita cita) {
        // TODO implement here

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public Set<Cita> getCitas() {
        return citas;
    }

    public void setCitas(Set<Cita> citas) {
        this.citas = citas;
    }

    public Propietario getPropietario() {
        return propietario;
    }

    public void setPropietario(Propietario propietario) {
        this.propietario = propietario;
    }

    public Set<Historial> getHistoriales() {
        return historiales;
    }

    public void setHistoriales(Set<Historial> historiales) {
        this.historiales = historiales;
    }
    

    @Override
    public String toString() {
        return "Mascota{" + "nombre=" + nombre + ", edad=" + edad + '}';
    }

}