package practicafinalnb;


import java.util.*;

/**
 * 
 */
public class Medico extends Persona {

    /**
     * Default constructor
     */
    public Medico(String especialidad, String Nombre, String NumTel, String Dir) {   
        super(Nombre, NumTel, Dir);
        this.especialidad = especialidad;
    }

    private String especialidad;

    /**
     * 
     */
    private Set<Cita> citas;

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public Set<Cita> getCitas() {
        return citas;
    }

    public void setCitas(Set<Cita> citas) {
        this.citas = citas;
    }

    @Override
    public String toString() {
        return "Medico{" + super.toString()+ "especialidad=" + especialidad + '}';
    }

   

}