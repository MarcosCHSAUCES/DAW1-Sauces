package practicafinalnb;


import java.util.*;

/**
 * 
 */
public class Historial {

    /**
     * Default constructor
     */
    public Historial(Date fecha, String diagnostico) {    
        this.fecha = fecha;
        this.diagnostico = diagnostico;
    }

    private Date fecha;

    /**
     * 
     */
    private String diagnostico;

    /**
     * 
     */
    private Mascota animal;

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

    public Mascota getAnimal() {
        return animal;
    }

    public void setAnimal(Mascota animal) {
        this.animal = animal;
    }

    @Override
    public String toString() {
        return "Historial{" + "fecha=" + fecha + ", diagnostico=" + diagnostico + '}';
    }

    
}