package practicafinalnb;


import java.util.*;

/**
 * 
 */
public class Persona {

    /**
     * Default constructor
     */
    public Persona(String Nombre, String NumTel, String Dir) {   
        this.Nombre = Nombre;
        this.NumTel = NumTel;
        this.Dir = Dir;
    }

    protected String Nombre;

    /**
     * 
     */
    protected String NumTel;

    /**
     * 
     */
    protected String Dir;

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getNumTel() {
        return NumTel;
    }

    public void setNumTel(String NumTel) {
        this.NumTel = NumTel;
    }

    public String getDir() {
        return Dir;
    }

    public void setDir(String Dir) {
        this.Dir = Dir;
    }

    
    @Override
    public String toString() {
        return "Persona{" + "Nombre=" + Nombre + ", NumTel=" + NumTel + ", Dir=" + Dir + '}';
    }


}