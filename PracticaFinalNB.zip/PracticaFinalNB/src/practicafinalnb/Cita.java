package practicafinalnb;

import java.time.LocalTime;
import java.util.*;

/**
 * 
 */
public class Cita {

    public Cita(Date fecha, LocalTime hora) {
        this.fecha = fecha;
        this.hora = hora;
    }
    
    /**
     * 
     */
    private Date fecha;

    /**
     * 
     */
    private LocalTime hora;

    /**
     * 
     */
    private Medico doctor;

    /**
     * 
     */
    private Mascota animal;

    /**
     * @param fecha 
     * @param Hora 
     */
    public void CambiarCita(Date fecha, LocalTime Hora) {

    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    public Medico getDoctor() {
        return doctor;
    }

    public void setDoctor(Medico doctor) {
        this.doctor = doctor;
    }

    public Mascota getAnimal() {
        return animal;
    }

    public void setAnimal(Mascota animal) {
        this.animal = animal;
    }

    @Override
    public String toString() {
        return "Cita{" + "fecha=" + fecha + ", hora=" + hora + '}';
    }

    
}