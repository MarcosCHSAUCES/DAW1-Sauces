package practicafinalnb;


import java.util.*;

/**
 * 
 */
public class Propietario extends Persona {

    /**
     * Default constructor
     */
    public Propietario(Date fechaIngre, String Nombre, String NumTel, String Dir) {
        super(Nombre, NumTel, Dir);
        this.fechaIngre = fechaIngre;
    }

    private Date fechaIngre;

    /**
     * 
     */
    private Set<Mascota> animal;

    public Date getFechaIngre() {
        return fechaIngre;
    }

    public void setFechaIngre(Date fechaIngre) {
        this.fechaIngre = fechaIngre;
    }

    public Set<Mascota> getAnimal() {
        return animal;
    }

    public void setAnimal(Set<Mascota> animal) {
        this.animal = animal;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getNumTel() {
        return NumTel;
    }

    public void setNumTel(String NumTel) {
        this.NumTel = NumTel;
    }

    public String getDir() {
        return Dir;
    }

    public void setDir(String Dir) {
        this.Dir = Dir;
    }

    @Override
    public String toString() {
        return "Propietario{" + super.toString() + "fechaIngre=" + fechaIngre + ", animal=" + animal + '}';
    }

}